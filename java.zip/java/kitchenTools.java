package Laci;

public abstract class kitchenTools {
    private final String COLOR = "";

    private Float volume;
    //konstruktorban adjunk paramétert, ami beállítja a volume értéket
    public kitchenTools(Float vol){
        volume = vol;
    }

    public String getColor(){
        return COLOR;
    };
}
