package Laci;

class LaciProba{
    public static void main(String[]args) {
        KitchenToolFactory factory = new KitchenToolFactory();
        kitchenTools pan1 = factory.Create("pan");
        kitchenTools pot1 = factory.Create("pot");
    }
}
