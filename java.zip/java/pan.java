package Laci;
public class pan extends kitchenTools{
    public pan (Float vol){
        super(vol);
}
    @Override
    public String getColor(){
        return "green";
    };
}
