package Laci;

public class pot extends kitchenTools {
    public pot(Float vol){
        super(vol);
    }
    @Override
    public String getColor(){
        return "red";
    };
}
