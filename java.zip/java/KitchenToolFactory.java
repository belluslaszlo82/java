package Laci;

public class KitchenToolFactory {
    public kitchenTools Create(String type) {
        if (type.equals("pot")) {
            return new pot(1.0f);
        } else if (type.equals("pan")) {
            return new pan(1.0f);
        }else return null;
    }
}
